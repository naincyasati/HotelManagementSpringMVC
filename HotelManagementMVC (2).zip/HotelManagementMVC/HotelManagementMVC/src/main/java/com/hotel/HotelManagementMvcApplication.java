package com.hotel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import com.hotel.Model.Hotel;
import com.hotel.service.Chef;

@SpringBootApplication
public class HotelManagementMvcApplication extends SpringBootServletInitializer {
@Autowired
	private Chef chef;
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(HotelManagementMvcApplication.class);
	}	

	public static void main(String[] args) {
		SpringApplication.run(HotelManagementMvcApplication.class, args);
	}
	@Bean
	public CommandLineRunner initDB() {
		return (args) -> {
			chef.save(new Hotel("navaj","pizza",200));
			chef.save(new Hotel("komal","burger",200));
			chef.save(new Hotel("krishna","pizza",200));
		};
	}
	
}
