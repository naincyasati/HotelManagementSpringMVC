package com.hotel.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hotel.Model.Hotel;
import com.hotel.service.Chef;



@Controller
@RequestMapping("hotel")
public class Manager {
	
	@Autowired
private Chef chef;
	public void SetChef(Chef chef) {
		this.chef=chef;
	}
	
	@GetMapping("/")
	public ModelAndView getOrder() {
		List<Hotel> order = chef.findAll();
		HashMap<String, List<Hotel>> hm = new HashMap<>();
		hm.put("list", order);
		return new ModelAndView("orderdetail", hm);
		
	}
	@DeleteMapping("/{orderId}")
	public ModelAndView deleteOrder(@PathVariable Integer orderId) {

	chef.deleteById(orderId);
	
	return null;
}
	
	@PostMapping("/update")
	public ModelAndView updateOrder(@RequestBody Hotel hotel) {
		
            Hotel save = chef.save(hotel);
            
			List<Hotel> order=chef.findAll();
			HashMap<String, List<Hotel>> model=new HashMap<String, List<Hotel>>();
			model.put("list", order);
			return new ModelAndView("orderdetail",model);

	}
	
	@PostMapping("/")
	public ModelAndView addOrder(@RequestBody Hotel hotel) {
    Hotel h = chef.save(hotel);

	List<Hotel> order=chef.findAll();
	HashMap<String, List<Hotel>> model=new HashMap<String, List<Hotel>>();
	model.put("list", order);
	return new ModelAndView("orderdetail",model);

	}

}
