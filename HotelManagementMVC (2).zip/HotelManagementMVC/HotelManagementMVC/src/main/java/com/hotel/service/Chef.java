package com.hotel.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.hotel.Model.Hotel;

@Service
public interface Chef extends JpaRepository<Hotel,Integer>{

}
